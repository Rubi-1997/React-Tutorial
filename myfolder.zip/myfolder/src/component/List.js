import React from 'react'

function List() {
  return (
    <div>
        <h1>I am {std.name} and my age is {std.age}</h1>
    </div>
  )
}

export default List