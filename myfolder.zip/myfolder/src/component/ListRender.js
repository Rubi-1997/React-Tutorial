import React from 'react'

function ListRender() {
    // const Students=["Rita","Sita","Poonam"]
    //  Making keys example
    //  let studentsName=Students.map((std,index)=><li key={index}>{std}</li>)
    // let numbers=[1,2,3,4,10,11,8]
      //  let result=numbers.length
  //  let result= numbers.map(numbers=><h1>{numbers=numbers*2}</h1>)

  // const students=[
  //   {
  //     name:"Kashish",
  //     age: 24
  //   },
  //   {
  //     name:"Shital",
  //     age: 25
  //   },
  //   {
  //     name:"Ummid",
  //     age: 26
  //   }
  // ]
  // let result=students.length
  return (
    <div>
  {/* <ul>
     {students.map((std,index)=><li key={index}>I am {std.name} and my age is {std.age} and indexnumbr {index}</li>)} */}
  {/* {Students.map((std,index)=><li key={index}>{std}</li>)} */}
       {/* {studentsName} */}
       {/* </ul> */}
        {/* <h1>list length:{result}</h1> */}
        {/* {numbers.map(numbers=><h1>{numbers=numbers*2}</h1>)} */}
        {/* {result} */}
        {/* printing Lists */}
        {/* {students.map(std=><h1>I am {std.name} and my age is {std.age}</h1>)} */}
        {/* {students.map(std=><List/>)} */}
    </div>
  )
}

export default ListRender