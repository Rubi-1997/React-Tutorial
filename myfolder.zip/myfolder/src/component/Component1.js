import React from 'react'

export default function Component1() {
  return (
    <div><h1> hello component1</h1></div>
  )
}
