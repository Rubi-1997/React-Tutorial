import React from 'react'

export default function () {
  return (
    <div><h1>hello component 2</h1></div>
  )
}
