import React from 'react'
import Style from'./Stylesheet1.module.css'

export default function Stylesheet1() {
  return (
    <div>
        <h1 className={Style.heading}>Stylesheet1</h1></div>
  )
}
