import React from 'react'
import Style from'./Stylesheet2.module.css'
export default function Stylesheet2() {
  return (
    <div><h1 className={Style.heading}>Stylesheet2</h1></div>
  )
}
