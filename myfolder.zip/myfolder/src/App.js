import React , {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import Greet from './component/Greet';
import Welcome from './component/Welcome';
import Message from './component/Message';
import Counter from './component/Counter'
import FunctionClicked from './component/FunctionClicked'
import ClassClicked from './component/ClassClicked '
import BindingEvent from './component/BindingEvent'
import ParentClass from './component/ParentClass';
import Conditional from './component/Conditional';
import ListRender from './component/ListRender';
import Stylesheet from './component/Stylesheet'
import ExternalCss from './component/ExternalCss';
import Stylesheet1 from './component/Stylesheet1';
import Stylesheet2 from './component/Stylesheet2';
import Form from './component/Form';
import Mounting from './component/Mounting';

class App extends Component {
  render(){
  return (
    
          <div className="App">
            {/* <Form/> */}
            <Mounting/>
            {/* <Stylesheet1/>
            <Stylesheet2/> */}
            {/* <ExternalCss check={true}/> */}
            {/* <Stylesheet/> */}
          {/* <Stylesheet primary={true}/> */}
             {/* <ListRender /> */}
            {/* <Conditional/> */}
            {/* <ParentClass/> */}
            {/* <BindingEvent /> */}
            {/* <Message/> */}
            {/* <FunctionClicked/>
            <ClassClicked /> */}
            {/* <Welcome name="Rekha"  heroname="Batman"/>
            <Welcome name="Ritu"  heroname="Batman"/>
            <Welcome name="Pawan"  heroname="Batman"/> */}
            <Counter />
            {/* <Message>
              <button>subscribe</button>
            </Message> */}
          {/* // <Greet  name="Rekha" heroname="Batman">
          //   <p>this is a children</p>
          // </Greet>
          // <Greet  name="Pawan" heroname="Batman">
          // <p>this is a children</p>
          //   </Greet>
          // <Greet name="Jeeva"  heroname="Batman">
          //   <button>click me</button>
          //   </Greet>*}
           <Welcome  name="Rekha"  heroname="Batman"/>
           <Welcome  name="Pawan"  heroname="Batman"/>
           <Welcome  name="Jeeva"  heroname="Batman"/> 
          */}
        </div>
  )
}
}

export default App;
